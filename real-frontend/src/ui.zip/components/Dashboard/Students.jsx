import React from "react";
import StudentTable from "../Students/StudentTable";

export default function Students() {
  return <StudentTable />;
}
